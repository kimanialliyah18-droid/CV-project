// script.js 

// DOM Elements
const navLinks = document.querySelectorAll('.nav-link');
const pages = document.querySelectorAll('.page');
const hamburger = document.querySelector('.hamburger');
const navLinksContainer = document.querySelector('.nav-links');
const contactForm = document.getElementById('contactForm');
const emailInput = document.getElementById('email');
const confirmEmailInput = document.getElementById('confirmEmail');
const projectDateInput = document.getElementById('projectDate');
const submitButton = document.getElementById('submit');

// Page Navigation Functionality
document.addEventListener('DOMContentLoaded', function() {

    const hash = window.location.hash || '#home';
    showPage(hash.substring(1));
    

    setActiveNavLink(hash.substring(1));
    

    initializeEventListeners();
    

    setMinDate();
});

/**
 * Shows  specified page,
 * @param {string} pageId - The ID of the page to show
 */
function showPage(pageId) {
    pages.forEach(page => {
        if (page.id === pageId) {
            page.classList.add('active');
        } else {
            page.classList.remove('active');
        }
    });
    
    // Update URL hash
    window.location.hash = pageId;
}



 * @param {string} pageId - The ID of the active page
 */
function setActiveNavLink(pageId) {
    navLinks.forEach(link => {
        if (link.getAttribute('href') === `#${pageId}`) {
            link.classList.add('active');
        } else {
            link.classList.remove('active');
        }
    });
}


function initializeEventListeners() {
    // Navigation links
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const pageId = this.getAttribute('href').substring(1);
            showPage(pageId);
            setActiveNavLink(pageId);
            
            // Close mobile menu if open
            if (navLinksContainer.classList.contains('active')) {
                navLinksContainer.classList.remove('active');
            }
        });
    });
    
    // Hamburger menu for mobile
    hamburger.addEventListener('click', function() {
        navLinksContainer.classList.toggle('active');
    });
    
    // Form validation
    if (contactForm) {
        // Real-time email validation
        emailInput.addEventListener('input', checkEmails);
        confirmEmailInput.addEventListener('input', checkEmails);
        projectDateInput.addEventListener('change', checkDate);
        
        // Form submission
        contactForm.addEventListener('submit', validateForm);
    }
    
    // Close mobile menu when clicking outside
    document.addEventListener('click', function(e) {
        if (!hamburger.contains(e.target) && !navLinksContainer.contains(e.target)) {
            navLinksContainer.classList.remove('active');
        }
    });
}

/**
 * Validates the entire contact form
 * @param {Event} e - The form submit event
 */
function validateForm(e) {
    e.preventDefault();
    
    console.log('Form validation started...');
    

    const firstName = document.getElementById('firstName').value.trim();
    const email = emailInput.value.trim();
    const confirmEmail = confirmEmailInput.value.trim();
    const projectDate = projectDateInput.value;
    const duration = document.getElementById('duration').value;
    const description = document.getElementById('description').value.trim();
    const contactMethod = document.querySelector('input[name="contactMethod"]:checked');
    
    let isValid = true;
    let errorMessages = [];
    
    // Validate first name
    if (!firstName) {
        isValid = false;
        errorMessages.push('First name is required');
        showError('firstName', 'Please enter your first name');
    } else {
        clearError('firstName');
    }
    
    // Validate email
    if (!email) {
        isValid = false;
        errorMessages.push('Email is required');
        showError('email', 'Please enter your email address');
    } else if (!isValidEmail(email)) {
        isValid = false;
        errorMessages.push('Email format is invalid');
        showError('email', 'Please enter a valid email address');
    } else {
        clearError('email');
    }
    
    // Validate confirm email
    if (!confirmEmail) {
        isValid = false;
        errorMessages.push('Confirm email is required');
        showError('confirmEmail', 'Please confirm your email address');
    } else if (email !== confirmEmail) {
        isValid = false;
        errorMessages.push('Emails do not match');
        showError('confirmEmail', 'Email addresses do not match');
    } else {
        clearError('confirmEmail');
    }
    
    // Validate project date
    if (!projectDate) {
        isValid = false;
        errorMessages.push('Project start date is required');
        showError('projectDate', 'Please select a project start date');
    } else if (!checkDate()) {
        isValid = false;
        errorMessages.push('Project date must be in the future');
    } else {
        clearError('projectDate');
    }
    
    // Validate duration
    if (!duration) {
        isValid = false;
        errorMessages.push('Project duration is required');
        showError('duration', 'Please select a project duration');
    } else {
        clearError('duration');
    }
    
    // Validate description
    if (!description) {
        isValid = false;
        errorMessages.push('Project description is required');
        showError('description', 'Please describe your project');
    } else if (description.length < 20) {
        isValid = false;
        errorMessages.push('Description must be at least 20 characters');
        showError('description', 'Please provide a more detailed description (minimum 20 characters)');
    } else {
        clearError('description');
    }
    
    // Validate contact method
    if (!contactMethod) {
        isValid = false;
        errorMessages.push('Preferred contact method is required');
        showError('contactMethod', 'Please select a preferred contact method');
    } else {
        clearError('contactMethod');
    }
    
    // If form is valid then submit it
    if (isValid) {
        console.log('Form is valid. Submitting...');
        
        // Disable submit button to prevent double submission
        submitButton.disabled = true;
        submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
        
        // Simulate form submission (in a real app, this would be an AJAX call)
        setTimeout(() => {
            alert('Thank you for your enquiry! I will contact you within 24 hours.');
            
            // Reset form
            contactForm.reset();
            
            // Reset submit button
            submitButton.disabled = false;
            submitButton.innerHTML = 'Send Enquiry';
            
            // Reset all errors
            clearAllErrors();
            
            console.log('Form submitted successfully');
        }, 1500);
    } else {
        console.log('Form validation failed:', errorMessages);
        
        // Show summary of errors
        if (errorMessages.length > 0) {
            const errorSummary = document.createElement('div');
            errorSummary.className = 'error-summary';
            errorSummary.style.cssText = `
                background-color: #ffebee;
                border: 1px solid #ff6b9d;
                border-radius: 4px;
                padding: 15px;
                margin-bottom: 20px;
                color: #c62828;
            `;
            
            errorSummary.innerHTML = `
                <strong>Please fix the following errors:</strong>
                <ul style="margin: 10px 0 0 20px;">
                    ${errorMessages.map(msg => `<li>${msg}</li>`).join('')}
                </ul>
            `;
            
            // Remove existing error summary if present
            const existingSummary = document.querySelector('.error-summary');
            if (existingSummary) {
                existingSummary.remove();
            }
            
            // Insert error summary at the top of the form
            contactForm.insertBefore(errorSummary, contactForm.firstChild);
            
            // Scroll to error summary
            errorSummary.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    }
    
    return isValid;
}

/**
 * Checks if two email addresses match
 * @returns {boolean} True if emails match, false otherwise
 */
function checkEmails() {
    const email = emailInput.value.trim();
    const confirmEmail = confirmEmailInput.value.trim();
    
    if (email && confirmEmail) {
        if (email === confirmEmail) {
            clearError('email');
            clearError('confirmEmail');
            return true;
        } else {
            showError('confirmEmail', 'Email addresses do not match');
            return false;
        }
    }
    
    return true;
}

/**
 * Checks if the project date is valid (not in the past)
 * @returns {boolean} True if date is valid, false otherwise
 */
function checkDate() {
    const selectedDate = new Date(projectDateInput.value);
    const today = new Date();
    
    // Set today's date to midnight for accurate comparison
    today.setHours(0, 0, 0, 0);
    
    if (selectedDate < today) {
        showError('projectDate', 'Project start date must be today or in the future');
        return false;
    } else {
        clearError('projectDate');
        return true;
    }
}

/**
 * Validates email format
 * @param {string} email - The email to validate
 * @returns {boolean} True if email is valid, false otherwise
 */
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

/**
 * Shows an error message for a form field
 * @param {string} fieldId - The ID of the field
 * @param {string} message - The error message
 */
function showError(fieldId, message) {
    const field = document.getElementById(fieldId);
    const formGroup = field.closest('.form-group');
    
    // Remove existing error if present
    const existingError = formGroup.querySelector('.error-message');
    if (existingError) {
        existingError.remove();
    }
    
    // Add error styling to field
    field.style.borderColor = '#ff6b9d';
    
    // Create and append error message
    const errorElement = document.createElement('div');
    errorElement.className = 'error-message';
    errorElement.style.cssText = `
        color: #ff6b9d;
        font-size: 0.85rem;
        margin-top: 5px;
    `;
    errorElement.textContent = message;
    
    formGroup.appendChild(errorElement);
}

/**
 * Clears error message for a form field
 * @param {string} fieldId - The ID of the field
 */
function clearError(fieldId) {
    const field = document.getElementById(fieldId);
    if (field) {
        const formGroup = field.closest('.form-group');
        
        // Remove error styling
        field.style.borderColor = '';
        
        const errorElement = formGroup.querySelector('.error-message');
        if (errorElement) {
            errorElement.remove();
        }
    }
}

function clearAllErrors() {
    const errorMessages = document.querySelectorAll('.error-message');
    errorMessages.forEach(error => error.remove());
    
    const fields = contactForm.querySelectorAll('input, select, textarea');
    fields.forEach(field => {
        field.style.borderColor = '';
    });
    
    const errorSummary = document.querySelector('.error-summary');
    if (errorSummary) {
        errorSummary.remove();
    }
}

/**
 * Sets the minimum date for the project date input to today
 */
function setMinDate() {
    if (projectDateInput) {
        const today = new Date().toISOString().split('T')[0];
        projectDateInput.min = today;
    }
}


document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        const href = this.getAttribute('href');
        

        if (href !== '#home' && href !== '#portfolio' && href !== '#contact-me') {
            e.preventDefault();
            
            const targetId = href.substring(1);
            const targetElement = document.getElementById(targetId);
            
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 80,
                    behavior: 'smooth'
                });
            }
        }
    });
});


window.addEventListener('resize', function() {
    if (window.innerWidth > 768) {
        navLinksContainer.classList.remove('active');
    }
});


console.log('Portfolio website JavaScript loaded successfully!');